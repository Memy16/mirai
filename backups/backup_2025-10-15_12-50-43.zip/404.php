<?php
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Error 404</title>
</head>
<body>
  <h1>Error 404 - Página no encontrada</h1>
  <img src="https://http.cat/404" alt="404 Not Found">
</body>
</html>
