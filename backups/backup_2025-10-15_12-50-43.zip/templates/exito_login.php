<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Redirigiendo...</title>
        <style>
            body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            }
            .toast {
            background: #4CAF50;
            color: white;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            font-size: 18px;
            animation: fadein 0.5s, fadeout 0.5s 2.5s;
            }
            @keyframes fadein {
            from {opacity: 0; transform: translateY(20px);}
            to {opacity: 1; transform: translateY(0);}
            }
            @keyframes fadeout {
            from {opacity: 1;}
            to {opacity: 0;}
            }
        </style>
    </head>
    <body>
        <div class="toast">
            ✅ Bienvenido/a <?= htmlspecialchars($usuario['rol']) ?> 
            <?= htmlspecialchars($usuario['nombre']) ?> 
            <?= htmlspecialchars($usuario['apellido']) ?><br>
            <small>ID de usuario: <?= htmlspecialchars($usuario['user_id']) ?></small><br>
            Serás redirigido en 3 segundos...
        </div>

        <script>
            setTimeout(function(){
            window.location.href = '<?= htmlspecialchars($usuario['home']) ?>';
            }, 3000);
        </script>
    </body>
</html>
